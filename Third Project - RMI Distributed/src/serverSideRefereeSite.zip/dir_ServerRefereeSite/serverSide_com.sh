java -Djava.rmi.server.codebase="http://l040101-ws02.ua.pt/sd0308/classes/"\
     -Djava.rmi.server.useCodebaseOnly=true\
     -Djava.security.policy=java.policy\
     ServerRefereeSite.RefereeSiteApp
