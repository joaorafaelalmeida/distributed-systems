java -Djava.rmi.server.codebase="http://l040101-ws04.ua.pt/sd0308/classes/"\
     -Djava.rmi.server.useCodebaseOnly=true\
     -Djava.security.policy=java.policy\
     ServerRepository.RepositoryApp
