rmiregistry -J-Djava.rmi.server.codebase="file:///home/sd0308/sd0308/GameOfRopeRMI/dir_ServerRepository/"\
            -J-Djava.rmi.server.useCodebaseOnly=true $1