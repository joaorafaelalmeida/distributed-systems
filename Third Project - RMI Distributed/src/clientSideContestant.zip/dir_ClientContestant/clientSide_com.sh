java -Djava.rmi.server.codebase="http://l040101-ws07.ua.pt/sd0308/classes/"\
     -Djava.rmi.server.useCodebaseOnly=false\
     ClientContestant.ContestantApp
